from app.models.log_proceso import LogProceso
from app.core.logger import getLogger

class LogProcesoRepository:

    def __init__(self):
        self.logger= getLogger(__name__)


    def insertar(self, log:LogProceso, schema, marker_position, conn):
        cursor: None

        try:
            p=marker_position       

            sql=f"""
                   INSERT INTO 
                   {schema}.TRALPR(
                   UUID, TIPO_LOG, MENSAJE, USUARIO, METODO, CLASE, ESTADO) 
                   VALUES ({p},{p},{p},{p},{p},{p},{p})
                   """

            cursor=conn.cursor()

            cursor.execute(sql, (
                log.uuid,log.tipo_log, 
                log.mensaje, log.usuario, 
                log.metodo, log.clase, 
                log.estado)
                )
            
            conn.commit()
            self.logger.info(f"log registrado correctamente(mensaje:{log.mensaje})")

        except Exception as e:
            self.logger.error(f"No se pudo insertar el log:{e}")
            raise 

        finally:

            if cursor is not None:
                cursor.close()

        

        


           






