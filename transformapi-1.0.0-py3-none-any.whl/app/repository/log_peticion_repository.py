from app.models.log_peticion_respuesta import LogPeticionRespuesta
from app.core.logger import getLogger

class LogPeRepository:

    def __init__(self):
        self.logger=getLogger(__name__)


    def insertar(self, log:LogPeticionRespuesta, schema, marker_position, conn):
        cursor=None

        try:
            p=marker_position

            sql= f"""
                INSERT INTO 
                {schema}.TRALPE(UUID,PET_USUARIO,RES_API,FECHA_PETICION,FECHA_RESPUESTA) 
                VALUES ({p},{p},{p},{p},{p}) 
                """
            cursor= conn.cursor()
            
            cursor.execute(sql,( 
                log.uuid, 
                log.pet_usuario, 
                log.res_api, 
                log.fecha_peticion, 
                log.fecha_respuesta)
                )
            
            conn.commit()

            self.logger.info("log registrado correctamente")

        except Exception as error:

            self.logger.error(f"No se pudo insertar el log {error}")
            raise

        finally:
            if cursor is not None:
                cursor.close()


    def actualizar(self, log:LogPeticionRespuesta, schema, marker_position, conn):
        cursor=None

        try:
            p=marker_position
            
            cursor= conn.cursor()

            sql= F"""
                UPDATE {schema}.TRALPE
                SET RES_API={p}, FECHA_RESPUESTA={p}
                WHERE UUID={p}
                """
            
            cursor.execute(sql,(
                log.res_api, 
                log.fecha_respuesta,
                log.uuid
                ))
            
            conn.commit()

            self.logger.info("actualizacion de log peticion y respuesta exitoso")

        except Exception as error:

            self.logger.error(f"no se pudo actualizar el log con uuid: {log.uuid}: {error}")
            raise 

        finally:
            if cursor is not None:
                cursor.close()

        
        


