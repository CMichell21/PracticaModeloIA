from fastapi import APIRouter, Depends, status, Request
from app.service.comparar_service import CompararService
from app.schemas.respuesta import Respuesta
import json

router = APIRouter(prefix="/transformapi")

orquestador = CompararService()

@router.post("/comparar", response_model=Respuesta,response_model_exclude_none=True)
async def comparar (request: Request):
    
    resultado= await orquestador.ejecutar_proceso(request)   

    return resultado
