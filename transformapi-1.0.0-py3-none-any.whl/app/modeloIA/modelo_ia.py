from sentence_transformers import SentenceTransformer
from sentence_transformers.util import cos_sim
from app.core.excepciones.errores_modeloIA import ErroresModeloIA
from app.core.logger import getLogger
import time
import torch

class ModeloIa:

    logger=getLogger(__name__)
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.modelo=SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2', device=self.device)


    def comparar(self,textoA,textoB):

        tiempo_inicial=time.perf_counter()
        try:
            self.logger.info(f"modelo ejecutandoce en dispositivo: {self.device}")

            tamaño_tokens_textoA=self.calcular_cantidad_tokens(textoA) 
            tamaño_tokens_textoB=self.calcular_cantidad_tokens(textoB)
            
            self.logger.info("Inicio procesamiento de embenddings")
            embeddings=self.modelo.encode([textoA,textoB], 
                                            convert_to_tensor=True,
                                            normalize_embeddings=True
                                            )
            self.logger.info("Procesamiento de embenddings finalizado correctamente")

            similitud=cos_sim(embeddings[0],embeddings[1]).item()
            
            self.logger.info(f"procesamiento del modelo exitoso=(similitud:{similitud}, tokens textoA:{tamaño_tokens_textoA}, tokens textoB:{tamaño_tokens_textoB})")

            return [similitud,tamaño_tokens_textoA,tamaño_tokens_textoB]

        except Exception as error:
            tipo_error=type(error).__name__

            if tipo_error =="ValueError":
                codigo="015"
                mensaje=str(error)

            else:
                self.logger.error(f"fallo el procesamiento del modelo:{error}, clase:{self.__class__.__name__}, metodo:comparar")
                codigo="016"
                mensaje="No se pudo realizar la operación"

            raise ErroresModeloIA(codigo, "ERROR", mensaje, "comparar", self.__class__.__name__,"ERROR")

        finally:

            tiempo_final=time.perf_counter()
            tiempo_total=tiempo_final - tiempo_inicial
            self.logger.info(f"tiempo duracion:{tiempo_total}")  

   
    def calcular_cantidad_tokens(self, texto):

        self.logger.info("calculando la cantidad de tokens que genera el texto")
        tamaño_texto=len(texto)

        tokens=self.modelo.tokenizer(
            texto,
            truncation=False,
            add_special_tokens=True
        )["input_ids"]
        
        tamaño_tokens=len(tokens)
        
        limite_tokens=self.modelo.tokenizer.model_max_length
        
        if tamaño_tokens > limite_tokens:

            self.logger.info(f"cantidad de tokens generado por el texto calculados exitosamente: {tamaño_tokens}")
            self.logger.error(f"Supero el limite  de {limite_tokens} tokens permitidos por el modelo, cantidad de caracteres: {tamaño_texto}, el texto: {texto}")

            raise ValueError(
                "No se pudo realizar la operación"
            )

        self.logger.info(f"cantidad de tokens generado por el texto calculados exitosamente: {tamaño_tokens}")

        return tamaño_tokens




