import traceback
from fastapi import FastAPI, Request
from app.api.comparar import router
from fastapi.responses import JSONResponse
from app.core.excepciones.errores_validacion import ErroresValidación
from app.core.excepciones.error_conexion_bd import ErrorConexionBD
from app.core.excepciones.errores_modeloIA import ErroresModeloIA
from app.core.excepciones.errores_app import ErroresApp

app = FastAPI(
    title="transformapi",
    description="api para poder consumir un modelo de ia"
)
  
app.include_router(router)



@app.exception_handler(ErroresValidación)
async def excepciones_validacion(request:Request, datos:ErroresValidación):
    return JSONResponse(
        status_code=200,
        content={
            "codigoMensaje":datos.codigo,
            "descripcionMensaje": datos.mensaje
        }
    )


@app.exception_handler(ErroresModeloIA)
async def excepciones_modelo(request:Request,datos:ErroresModeloIA):
    return JSONResponse(
        status_code=500,
        content={
            "codigoMensaje":datos.codigo,
            "descripcionMensaje":datos.mensaje
        }
    )

@app.exception_handler(ErrorConexionBD)
async def excepciones_base_datos(request:Request,datos:ErrorConexionBD):
    return JSONResponse(
        status_code=500,
        content={
            "codigoMensaje":datos.codigo,
            "descripcionMensaje":datos.mensaje
        }
    )

@app.exception_handler(Exception)
async def excepciones_servidor(request:Request, ctx:Exception):
    return JSONResponse(
        status_code=500,
        content={
            "codigoMensaje":"018",
            "descripcionMensaje":"No se pudo realizar la operación"
        }
    )

