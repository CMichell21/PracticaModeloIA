from app.core.logger import getLogger
from app.models.log_proceso import LogProceso
from app.core.excepciones.errores_validacion import ErroresValidación
from app.repository.log_proceso_repository import LogProcesoRepository
from app.models.log_proceso import LogProceso


class ValidarServicioService:
    
    def __init__(self):
        self.servicios= {
            1: "comparar_texto"
        }
        self.logger= getLogger(__name__)
        self.log_repository=LogProcesoRepository()

    def validar(self, servicio):

        self.logger.info("Validando servicio")

        servicio_validado= self.servicios.get(servicio)
        
        if servicio_validado is None:
            self.logger.error("Servicio validado exitosamente pero no se encuentra disponible")
            raise ErroresValidación("009","WARNING","servicio no disponible actualmente","validar",self.__class__.__name__, "ALERTA")
        
        self.logger.info("Servicio validado exitosamente")     
        return servicio_validado