from app.core.config import Config
#from app.dbconexion.conexion_db2 import ConexionDb2
from app.dbconexion.conexion_sql import ConexionSql
from app.service.validar_servicio_service import ValidarServicioService
from app.repository.log_proceso_repository import LogProcesoRepository
from app.repository.log_peticion_repository import LogPeRepository
from app.models.log_proceso import LogProceso
from app.models.log_peticion_respuesta import LogPeticionRespuesta
from app.service.validar_entrada_service import ValidarEntradaService
from app.service.analisis_similitud_service import AnalisisSimilitudService
from app.core.excepciones.errores_validacion import ErroresValidación
from app.core.excepciones.error_conexion_bd import ErrorConexionBD
from app.core.excepciones.errores_modeloIA import ErroresModeloIA
from app.core.logger import getLogger
from datetime import datetime, timezone
import json
import uuid
import time
import traceback

class CompararService:
     
    def __init__(self):
            self.logger=getLogger(__name__)
            self.config=Config()
            #self.conectar=ConexionDb2()
            self.conectar=ConexionSql()
            self.validar_servicio= ValidarServicioService()
            self.comparar=AnalisisSimilitudService()
            self.log_repository=LogProcesoRepository()
            self.logpe_repository=LogPeRepository()
            self.validar_entrada=ValidarEntradaService()
        

    async def ejecutar_proceso(self, datos_entrada):

        tiempo_inicial=time.perf_counter()
 
        respuesta=None
        parametros=None
        conn= None
        peticion=None
        uuid_log=None

        try:
            self.logger.info("############# INICIO DEL PROCESO ################")
            ############### PASO 1: OBTENER PARAMETROS DEL ARCHIVO DE PROPIEDADES ###############
            parametros=self.config.parametros()

            ############### PASO 2: OBTENER CONEXION BASE DE DATOS #################
            ##---CONEXION DB2

            #conn=self.conectar.conectar(
            #    parametros["db_driver"],
            #    parametros["url_ip"],
            #    parametros["db_user"],
            #    parametros["db_password"],
            #    parametros["db_jar"],
            #    parametros["time_conection"]
            #)

            ###---CONEXION SQL SERVER

            conn=self.conectar.conectar(
                parametros["url_ip"],
                parametros["port"],
                parametros["db_user"],
                parametros["db_password"],
                parametros["db_name"],
                parametros["time_conection"],
                parametros["time_read"]
            )

            ## generar uuid para los logs de bitacora 
            uuid_log=str(uuid.uuid4())


            #PRIMEROS INSERT A LAS TABLAS DE BITACORA
            ## transformamos el elemento de fastapi en un objeto dict de python
            datos_entrada_dict=await datos_entrada.json()

            ## convertimos el objeto dict en un string para poder registrarlo en la base de datos
            pet_usuario=str(datos_entrada_dict)

            ## calculamos la fecha de entrada de la peticion
            fecha_peticion = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

            self.logpe_repository.insertar(
                LogPeticionRespuesta(
                    uuid_log,
                    pet_usuario,
                    "",
                    fecha_peticion,
                    fecha_peticion,
                ), parametros["schema"], parametros["marker_position"], conn
            )

            self.log_repository.insertar(
                LogProceso(
                    uuid_log,
                    "INFO",
                    "**** INICIO DEL PROCESO ****",
                    "",
                    "ejecutar_proceso",
                    self.__class__.__name__,
                    "OK"
                ), parametros["schema"], parametros["marker_position"], conn
            )

            self.log_repository.insertar(
                LogProceso(
                    uuid_log,
                    "INFO",
                    "Obtencion de parametros realizada exitosamente",
                    "",
                    "obtener_parametros",
                    "Config",
                    "OK"
                ), parametros["schema"], parametros["marker_position"], conn
            )
            
            self.log_repository.insertar(
                LogProceso(
                    uuid_log,
                    "INFO",
                    "Conexion a la base de datos establecida exitosamente",
                    "",
                    "conectar",
                    "ConexionSql",
                    "OK"
                ), parametros["schema"], parametros["marker_position"], conn
            )

            ################### PASO 3: VALIDACION DE ENTRADA ####################
            self.log_repository.insertar(LogProceso(
                uuid_log,
                "INFO",
                "Validando el json de entrada a la api",
                "",
                "validar",
                "ValidarEntradaService",
                "OK"
                ), parametros["schema"], parametros["marker_position"], conn
            )

            peticion= self.validar_entrada.validar(
                datos_entrada_dict,
            )

            self.log_repository.insertar(LogProceso(
                uuid_log,
                "INFO",
                "Validacion del json de entrada realizada exitosamente",
                peticion.usuario,
                "validar",
                "ValidarEntradaService",
                "OK"
                ), parametros["schema"], parametros["marker_position"], conn
            )
         
            ################### PASO 4: VALIDACION DE SERVICIO ########################
            self.log_repository.insertar(LogProceso(
                uuid_log,
                "INFO",
                "Validando servicio",
                peticion.usuario,
                "validar",
                "ValidarServicioService",
                "OK"
                ), parametros["schema"], parametros["marker_position"], conn
            )

            servicio=self.validar_servicio.validar(
                peticion.servicio, 
            )
            
            self.log_repository.insertar(LogProceso(
                uuid_log,
                "INFO",
                "Servicio validado exitosamente",
                peticion.usuario,
                "validar",
                "ValidarServicioService",
                "OK"
                ), parametros["schema"], parametros["marker_position"], conn
            )   

            ####################### PASO 5: EJECUTAR SERVICIO ########################
            if servicio == "comparar_texto":
                respuesta_modelo=self.comparar.comparar_textos(
                                        peticion.textoA,
                                        peticion.textoB,
                                        parametros["umbral"],
                                        parametros["umbral1"],
                                        parametros["umbral2"],
                                        uuid_log,peticion.usuario,parametros["schema"], 
                                        parametros["marker_position"], 
                                        conn
                                        )
           
            ################### PASO 6: VALIDAR SALIDA DE LA API ####################
            respuesta_api=self.validar_entrada.validar_respuesta(respuesta_modelo)

            respuesta=str(respuesta_modelo)
            return respuesta_api
            #return respuesta_api.model_dump(exclude_none=True)
        
        except ErrorConexionBD as error:
            raise
        
        except ErroresValidación as error:  ######### capturamos errores de validacion campos enviados por el usuario y disponibilidad del servicio
            respuesta=str({"codigoMensaje":error.codigo,
                       "descripcionMensaje": error.mensaje 
                    })
            self.logger.info(respuesta)

            usuario=getattr(peticion,"usuario", None)

            if peticion is None:
                usuario="transformapi"

            self.log_repository.insertar(
                LogProceso(
                    uuid_log,
                    error.tipo_log,
                    f"{error.codigo}: {error.mensaje}",
                    usuario,
                    error.metodo,
                    error.clase,
                    error.estado
                ), parametros["schema"], parametros["marker_position"], conn
            )           
            raise
        
        except ErroresModeloIA as error:
            respuesta=str({"codigoMensaje":error.codigo,
                            "descripcionMensaje": error.mensaje})
        
                
            self.log_repository.insertar(
                LogProceso(
                    uuid_log,
                    error.tipo_log,
                    error.mensaje,
                    peticion.usuario,
                    error.metodo,
                    error.clase,
                    error.estado
            ), parametros["schema"], parametros["marker_position"], conn)

            raise

        except Exception as error: 

            respuesta= str({"codigoMensaje":"018",
                            "descripcionMensaje": error})
            if conn is not None and uuid_log is not None:
                self.log_repository.insertar(
                    LogProceso(
                        uuid_log,
                        "ERROR",
                        str(error),
                        "transformapi",
                        "ejecutar_proceso",
                        self.__class__.__name__,
                        "ERROR"
                    ), parametros["schema"], parametros["marker_position"], conn
                )

            raise

        finally:
            if conn is not None:

                self.log_repository.insertar(
                    LogProceso(
                        uuid_log,
                        "INFO",
                        "**** FIN DEL PROCESO ****",
                        "",
                        "ejecutar_proceso",
                        self.__class__.__name__,
                        "OK"
                    ), parametros["schema"], parametros["marker_position"], conn
                )

                ## calculo de fecha respuesta al usuario
                fecha_respuesta = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

                self.logpe_repository.actualizar(
                    LogPeticionRespuesta(
                        uuid_log,
                        "",
                        respuesta,
                        fecha_respuesta,
                        fecha_respuesta
                    ), parametros["schema"], parametros["marker_position"], conn
                )
            
            
            self.conectar.desconectar(conn)

            tiempo_final=time.perf_counter()
            tiempo_total=tiempo_final - tiempo_inicial
            self.logger.info(f"tiempo total de todo el procesamiento{tiempo_total}")
            self.logger.info("############## FIN DEL PROCESO #####################")
            
            
            

        



        

