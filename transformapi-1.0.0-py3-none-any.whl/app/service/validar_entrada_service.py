from app.schemas.peticion import Peticion
from app.schemas.respuesta import Respuesta
from pydantic import ValidationError
from app.core.excepciones.errores_validacion import ErroresValidación
from app.core.logger import getLogger
from app.repository.log_proceso_repository import LogProcesoRepository
from app.models.log_proceso import LogProceso


class ValidarEntradaService:
    def __init__(self):
        self.logger=getLogger(__name__)
        self.log_repository=LogProcesoRepository()

    ###### CODIGOS DE ERROR DE VALIDACIONES
    
    def definir_respuesta_excepcion(self, detalle):

        respuesta={}

        tipo=detalle["type"]
        campo=detalle["loc"][-1]
        mensaje=detalle["msg"]
        dato_ingresado=detalle["input"]

        if tipo== "string_type":
            codigo="001"
            mensaje=f"El campo {campo} esperaba una cadena pero recibio un tipo de dato distinto"

        elif tipo=="int_type" or tipo=="int_parsing":
            codigo="001"
            mensaje=f"El campo {campo} esperaba un entero pero recibio un tipo de dato distinto"
        
        elif tipo =="string_too_long":
            codigo="002"
            tamaño_campo=detalle["ctx"]["max_length"]
            mensaje=f"El campo excedio el limite esperado de {tamaño_campo} caracteres"
        
        elif tipo== "string_too_short":
            codigo="002"
            tamaño_campo=detalle["ctx"]["min_length"]
            mensaje=f"El campo debe tener una longitud mayor o igual de {tamaño_campo} caracter"

        elif tipo== "less_than_equal":
            codigo="003"
            tamaño_campo=detalle["ctx"]["le"]
            mensaje=f"El campo debe ser menor o igual que {tamaño_campo}"
        
        elif tipo=="greater_than_equal":
            codigo="003"
            tamaño_campo=detalle["ctx"]["ge"]
            mensaje=f"El campo debe ser mayor o igual que {tamaño_campo}"
        
        elif tipo=="missing":
            codigo="004"
            mensaje=f"El campo {campo} es obligatorio"
        
        elif tipo=="extra_forbidden":
            codigo="005"
            mensaje=f"El campo {campo} no esta permitido"
        
        elif tipo=="string_pattern_mismatch":
            codigo="006"
            mensaje=f"El campo {campo} contiene caracteres no permitidos. Solo se permiten letras, números, - y _, sin espacios."
        
        respuesta = {
            "codigo":codigo,
            "nombre del campo": campo,
            "mensaje":mensaje
        }

        if tipo not in ("missing","extra_forbidden"):
            respuesta["dato ingresado"] = dato_ingresado
       
        return respuesta


    def validar(self, datos_entrada_dict):

        try:
            self.logger.info("Validando el json de entrada a la api")
            
            peticion= Peticion(**datos_entrada_dict)

            self.logger.info("Validación del json de entrada exitoso")

            return peticion.peticion

        except ValidationError as error:

            self.logger.warning("Fallo la validación del json de entrada")
            campos_invalidos=[]

            for detalle in error.errors():

                campo=self.definir_respuesta_excepcion(detalle)
                campos_invalidos.append(campo)
            
            self.logger.error(campos_invalidos)
            tamaño_campos_invalidos= len(campos_invalidos)

            if tamaño_campos_invalidos > 1:
               codigo_mensaje="008"
            else:
                codigo_mensaje=campos_invalidos[0]["codigo"]
            
            self.logger.warning(f"Datos ingresados incorrectos:{error}")
            raise ErroresValidación(codigo_mensaje,"WARNING",f"Datos invalidos: {campos_invalidos}","validar", self.__class__.__name__,"ALERTA")



    def validar_respuesta(self, respuesta_api):

        try:

            respuesta= Respuesta(**respuesta_api)
            self.logger.info("Validacion de respuesta al usuario exitosa")

            return respuesta
            
        except ValidationError as error:

            self.logger.error("fallo la validacion de respuesta de la api")
            raise ErroresValidación(400,"WARNING",f"fallo la validacion de respuesta de  la api:{error}","validar_respuesta", self.__class__.__name__,"ALERTA")


