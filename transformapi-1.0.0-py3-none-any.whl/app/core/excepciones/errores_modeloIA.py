from app.core.excepciones.errores_app import ErroresApp


class ErroresModeloIA(ErroresApp):
    pass