from app.core.excepciones.errores_app import ErroresApp

class ErroresValidación(ErroresApp):
    pass