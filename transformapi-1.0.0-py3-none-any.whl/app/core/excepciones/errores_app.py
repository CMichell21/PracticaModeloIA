class ErroresApp(Exception):

    def __init__(self,codigo,tipo_log, mensaje,metodo,clase, estado):
        self.codigo=codigo
        self.tipo_log=tipo_log
        self.mensaje=mensaje
        self.metodo=metodo
        self.clase=clase
        self.estado=estado
        super().__init__(mensaje)