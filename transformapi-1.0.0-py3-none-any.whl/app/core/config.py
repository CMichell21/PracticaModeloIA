import os
from dotenv import load_dotenv
from app.core.logger import getLogger
from app.core.excepciones.error_conexion_bd import ErrorConexionBD

class Config:

    logger = getLogger()
    
    def __init__(self,file=".env"):
        load_dotenv(file)


    def parametros(self):
        self.logger.info("Obteniendo parametros")
        
        return {
            "db_driver": self.obtener_propiedades_opcionales('NAME_DRIVER'), ##NOMBRE DEL DRIVER JDBC PARA DB2
            "url_ip": self.obtener_propiedades('URL_IP'),
            "port": self.obtener_propiedades('PORT'),
            "db_user": self.obtener_propiedades('DB_USER'),
            "db_password": self.obtener_propiedades('DB_PASSWORD'),
            "db_name": self.obtener_propiedades('DB'), ## nombre de la base de datos SQL-SERVER
            "db_jar": self.obtener_propiedades_opcionales('ADDRES_DRIVER'), ## ES LA RUTA DEL DRIVER JDBC PARA DB2
            "time_conection": self.obtener_propiedades_opcionales('TIME_CONECTION','10'),
            "time_read": self.obtener_propiedades_opcionales('TIME_READ','60'),

            #parametros para realizar insert o consultas
            "schema": self.obtener_propiedades('SCHEMA'),
            "marker_position": self.obtener_propiedades('MARKER_POSITION'),

            # Datos para el modelo de IA
            "umbral": self.obtener_propiedades('UMBRAL'),
            "umbral1": self.obtener_propiedades_opcionales('UMBRAL1'),
            "umbral2": self.obtener_propiedades_opcionales('UMBRAL2')
        }


    def obtener_propiedades(self,parametro):
        
        value= os.getenv(parametro)

        if value is None or value.strip() == "":
            self.logger.error(f"No se pudo obtener el parametro {parametro}")
            raise ErrorConexionBD("011", "No se pudo realizar la operacion")             
       
        return value.strip()

    
    def obtener_propiedades_opcionales(self, parametro, default=None):
        
        value= os.getenv(parametro)

        if value is None or value.strip()=="":
            return default
        
        return value.strip()
    

    



   
    


  