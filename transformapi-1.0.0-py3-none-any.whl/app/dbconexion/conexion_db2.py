from app.core.excepciones.error_conexion_bd import ErrorConexionBD
from app.core.logger import getLogger 
import jaydebeapi
import time

class ConexionDb2:

    def __init__(self):
        self.logger=getLogger(__name__)

    def conectar(
        self, db_driver, url_ip, 
        db_user, db_password, 
        db_jar, time_conection ):
        
        tiempo_inicial=time.perf_counter()
        try:
            self.logger.info("obteniendo conexion de la base de datos")
            conn= jaydebeapi.connect(
                db_driver,
                f"jdbc:{url_ip}",
                [db_user, db_password],
                db_jar
            )

            self.logger.info("conexion exitosa")

            return conn

        except Exception as error :

            self.logger.error(f"no se pudo obtener la conexion{error}")
            raise ErrorConexionBD("012", "fallo la conexion a la base de datos")

        finally:
            tiempo_final=time.perf_counter()
            tiempo_total=tiempo_final-tiempo_inicial

            self.logger.info(f"tiempo maximo de conexion esperado:{time_conection}, tiempo duracion:{tiempo_total}")

            

    def desconectar(self, conn):

        try:

            if conn is not None:
                conn.close()
                self.logger.info("conexion cerrada exitosamente")

        except Exception as error:

            self.logger.error(f"no se pudo cerrar la conexion{e}")

            
            
    

    
