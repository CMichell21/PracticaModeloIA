from pydantic import BaseModel, Field, ConfigDict, StrictInt
from typing import Optional,Annotated

class CuerpoPeticion(BaseModel):
    model_config = ConfigDict(extra="forbid")
    aplicacion:str=Field(min_length=1, max_length=20, pattern=r"^[A-Za-z0-9_-]+$")
    servicio:Annotated[StrictInt, Field(ge=1, le=9999)]
    usuario:Optional[str]=Field(
        default="transformapi",
        min_length=1,
        max_length=30,
        pattern=r"^[A-Za-z0-9_-]+$"
        )
    terminal:Optional[str]=Field(
        min_length=1, 
        max_length=30,
        pattern=r"^[A-Za-z,0-9_-]+$"
        )
    textoA:str=Field(min_length=1,max_length=720)
    textoB:str=Field(min_length=1,max_length=720)

class Peticion(BaseModel):
    
    model_config = ConfigDict(extra="forbid")
    peticion:CuerpoPeticion